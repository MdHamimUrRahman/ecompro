<div style="clear:both" class="panel panel-default">
    <div class="panel-body">
      Amit Fashion Gallery
    </div>
    <div class="panel-footer">Customer Care : +8801785212798</div>
  </div><?php /**PATH C:\Users\amitr\OneDrive\Desktop\New folder (3)\ecompro\resources\views/footer.blade.php ENDPATH**/ ?>